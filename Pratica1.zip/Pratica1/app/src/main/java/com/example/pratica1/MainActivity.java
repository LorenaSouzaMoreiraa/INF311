package com.example.pratica1;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main);

        final Button bt1= (Button) findViewById(R.id.atividade1);
        final Button bt2= (Button) findViewById(R.id.atividade2);


        bt1.setOnClickListener(new Button.OnClickListener(){
            public void onClick(View v){
                setContentView(R.layout.atividade1);

                Button btsum1= (Button) findViewById(R.id.sum1);
                Button btminus1= (Button) findViewById(R.id.minus1);
                Button btmultiply1= (Button) findViewById(R.id.multiply1);
                Button btdivide1 = (Button) findViewById(R.id.divide1);

                TextView result1 = (TextView) findViewById(R.id.result1);

                public void calcule(){
                    String tag = v.getTag().toString();
                    if(tag.equals("")) {
                        result1.setText()
                    }
                }
            }
        });
    }
}